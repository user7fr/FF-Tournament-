import { useState } from "react";

const PLACEMENT_POINTS = { 1:12, 2:9, 3:8, 4:7, 5:6, 6:5, 7:4, 8:3, 9:2, 10:2, 11:1, 12:1 };
const getPlacementPts = (pos) => PLACEMENT_POINTS[pos] || 0;
const ADMIN_PASSWORD = "admin123";

const sampleTeams = [
  { id:1, name:"Alpha Squad",   captain:"xAlpha99",  email:"alpha@gmail.com", phone:"9876543210", ffId:"FF123456", players:["xAlpha99","KillMaster","ShadowFF","NightOwl"],  checkedIn:true,  wins:2, losses:1, paid:true  },
  { id:2, name:"BloodHawk",     captain:"BH_Leader", email:"bloodhawk@gmail.com", phone:"9123456780", ffId:"FF234567", players:["BH_Leader","RedEye","DarkWolf","IronFist"],      checkedIn:true,  wins:1, losses:2, paid:true  },
  { id:3, name:"Storm Riders",  captain:"StormKing", email:"storm@gmail.com", phone:"9001234567", ffId:"FF345678", players:["StormKing","ThunderBolt","FlashFF","BlazeX"],    checkedIn:false, wins:3, losses:0, paid:true  },
  { id:4, name:"Ghost Killers", captain:"GhostFF",   email:"ghost@gmail.com", phone:"9988776655", ffId:"FF456789", players:["GhostFF","Phantom","Wraith","Specter"],          checkedIn:true,  wins:2, losses:1, paid:false },
];

const sampleApplications = [
  { id:101, teamName:"Nova Blasters", captain:"NovaX", email:"nova@gmail.com", phone:"9111222333", ffId:"FF567890", players:"NovaX, FlashKing, RapidFire, IceSniper", entryFee:200, utr:"UTR123456789", status:"pending",  appliedAt:"10 min ago" },
  { id:102, teamName:"Dark Phoenix",  captain:"DarkPH", email:"darkph@gmail.com", phone:"9444555666", ffId:"FF678901", players:"DarkPH, AshWing, CrimsonBolt, NightHawk", entryFee:200, utr:"UTR987654321", status:"pending",  appliedAt:"25 min ago" },
  { id:103, teamName:"Cyber Wolves",  captain:"CyberW", email:"cyber@gmail.com", phone:"9777888999", ffId:"FF789012", players:"CyberW, DataKill, NetRaider, ByteSniper", entryFee:200, utr:"UTR456123789", status:"approved", appliedAt:"1 hr ago"   },
];

const RULES = [
  { title:"Match Format",       content:"Battle Royale — 6 teams per lobby. Best of 6 matches. Points accumulate across all matches." },
  { title:"Kill Points",        content:"1 point per kill. No cap on kill points per match." },
  { title:"Placement Points",   content:"Booyah=12, #2=9, #3=8, #4=7, #5=6, #6=5, #7=4, #8=3, #9-10=2, #11-12=1" },
  { title:"Check-in",           content:"All teams must check in 15 minutes before match start. Failure results in disqualification." },
  { title:"Disconnections",     content:"No remake for disconnections. Team must continue with remaining members." },
  { title:"Disputes",           content:"Submit screenshot evidence within 10 minutes of match end. Admin decision is final." },
  { title:"Fair Play",          content:"No hacking, emulators, or teaming. Instant ban and disqualification." },
  { title:"Prize Distribution", content:"1st: 50% | 2nd: 30% | 3rd: 20% of prize pool. Paid within 48 hours of tournament end." },
];

// ── ATOMS ─────────────────────────────────────────────────
function Badge({ color, children }) {
  const c = {
    green:{bg:"#0d2a1a",text:"#00e676",border:"#00e67633"},
    red:{bg:"#2a0d0d",text:"#ff1744",border:"#ff174433"},
    orange:{bg:"#2a1a0d",text:"#ff6b00",border:"#ff6b0033"},
    blue:{bg:"#0d1a2a",text:"#29b6f6",border:"#29b6f633"},
    gray:{bg:"#1a1a1a",text:"#888",border:"#33333366"},
  }[color]||{bg:"#1a1a1a",text:"#888",border:"#33333366"};
  return <span style={{background:c.bg,color:c.text,border:`1px solid ${c.border}`,borderRadius:6,padding:"2px 8px",fontSize:11,fontWeight:700,whiteSpace:"nowrap"}}>{children}</span>;
}
function Card({ children, style={} }) {
  return <div style={{background:"#13131a",borderRadius:14,padding:14,border:"1px solid #1e1e2e",marginBottom:10,...style}}>{children}</div>;
}
function Inp({ style={}, ...p }) {
  return <input {...p} style={{width:"100%",padding:"11px 13px",background:"#0a0a0f",border:"1px solid #2a2a3a",borderRadius:10,color:"#fff",fontSize:14,boxSizing:"border-box",outline:"none",...style}} />;
}
function Btn({ children, onClick, variant="primary", style={}, disabled=false }) {
  const v = {
    primary:{background:"linear-gradient(135deg,#ff6b00,#ff0055)",color:"#fff"},
    secondary:{background:"#1e1e2e",color:"#aaa",border:"1px solid #2a2a3a"},
    danger:{background:"#2a0d0d",color:"#ff1744",border:"1px solid #ff174433"},
    success:{background:"#0d2a1a",color:"#00e676",border:"1px solid #00e67633"},
    blue:{background:"#0d1a2a",color:"#29b6f6",border:"1px solid #29b6f633"},
  }[variant];
  return <button onClick={onClick} disabled={disabled} style={{padding:"12px 16px",border:"none",borderRadius:10,fontWeight:700,fontSize:14,cursor:disabled?"not-allowed":"pointer",width:"100%",opacity:disabled?0.5:1,...v,...style}}>{children}</button>;
}
function Label({ children }) {
  return <div style={{fontSize:11,color:"#666",marginBottom:5,letterSpacing:0.5,fontWeight:600}}>{children}</div>;
}

// ── ADMIN LOCK ────────────────────────────────────────────
function AdminLock({ onUnlock }) {
  const [pw, setPw] = useState(""); const [err, setErr] = useState(false); const [shake, setShake] = useState(false);
  const tryLogin = () => {
    if(pw===ADMIN_PASSWORD){onUnlock();}
    else{setErr(true);setShake(true);setPw("");setTimeout(()=>setShake(false),500);setTimeout(()=>setErr(false),2000);}
  };
  return (
    <div style={{minHeight:"100vh",background:"#0a0a0f",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:24}}>
      <style>{`@keyframes shake{0%,100%{transform:translateX(0)}20%,60%{transform:translateX(-8px)}40%,80%{transform:translateX(8px)}}`}</style>
      <div style={{fontSize:56,marginBottom:8}}>🔐</div>
      <div style={{fontSize:22,fontWeight:800,color:"#ff6b00",marginBottom:4}}>Admin Access</div>
      <div style={{fontSize:13,color:"#555",marginBottom:32,textAlign:"center"}}>Enter your password to manage this tournament</div>
      <div style={{width:"100%",maxWidth:340,animation:shake?"shake 0.4s":"none"}}>
        <Inp type="password" placeholder="Admin password" value={pw} onChange={e=>setPw(e.target.value)} onKeyDown={e=>e.key==="Enter"&&tryLogin()} style={{marginBottom:10,fontSize:16,textAlign:"center",letterSpacing:4,border:err?"1px solid #ff1744":"1px solid #2a2a3a"}} />
        {err&&<div style={{textAlign:"center",color:"#ff1744",fontSize:12,marginBottom:8}}>❌ Wrong password</div>}
        <Btn onClick={tryLogin}>Unlock Dashboard</Btn>
      </div>
      <div style={{marginTop:24,fontSize:11,color:"#333",textAlign:"center"}}>Default: <span style={{color:"#555",fontFamily:"monospace"}}>admin123</span></div>
    </div>
  );
}

// ── PUBLIC REGISTRATION FORM ──────────────────────────────
function Register({ tournamentName, entryFee, upiId, maxTeams, approvedCount, onSubmit }) {
  const [step, setStep] = useState(1); // 1=form 2=payment 3=done
  const [form, setForm] = useState({ teamName:"", captain:"", email:"", phone:"", ffId:"", players:"", utr:"" });
  const [errors, setErrors] = useState({});

  const set = (k,v) => setForm(f=>({...f,[k]:v}));

  const validate1 = () => {
    const e = {};
    if(!form.teamName.trim()) e.teamName="Required";
    if(!form.captain.trim()) e.captain="Required";
    if(!form.email.includes("@")) e.email="Valid Gmail required";
    if(form.phone.length<10) e.phone="Valid phone required";
    if(!form.ffId.trim()) e.ffId="Required";
    if(!form.players.trim()) e.players="Required";
    setErrors(e);
    return Object.keys(e).length===0;
  };

  const isFull = approvedCount >= maxTeams;

  if(isFull && step===1) return (
    <div style={{padding:16}}>
      <Card style={{textAlign:"center",padding:"40px 20px",border:"1px solid #ff174433"}}>
        <div style={{fontSize:48}}>🔒</div>
        <div style={{fontSize:18,fontWeight:800,color:"#ff1744",marginTop:12}}>Tournament Full</div>
        <div style={{fontSize:13,color:"#888",marginTop:8}}>All {maxTeams} slots have been filled. Check back for future tournaments.</div>
      </Card>
    </div>
  );

  if(step===3) return (
    <div style={{padding:16}}>
      <Card style={{textAlign:"center",padding:"40px 20px",background:"linear-gradient(135deg,#0d2a1a,#1a2a0d)",border:"1px solid #00e67633"}}>
        <div style={{fontSize:56}}>🎉</div>
        <div style={{fontSize:20,fontWeight:800,color:"#00e676",marginTop:12}}>Registration Submitted!</div>
        <div style={{fontSize:13,color:"#aaa",marginTop:8,lineHeight:1.6}}>
          Your team <strong style={{color:"#fff"}}>{form.teamName}</strong> has been submitted for review.<br/>
          The admin will verify your payment and approve your slot.<br/>
          You'll be notified via the WhatsApp/Discord group.
        </div>
        <div style={{marginTop:20,background:"#0a0a0f",borderRadius:10,padding:"12px",fontSize:12,color:"#888"}}>
          <div>UTR/Reference: <strong style={{color:"#ff6b00",fontFamily:"monospace"}}>{form.utr}</strong></div>
          <div style={{marginTop:4}}>Amount Paid: <strong style={{color:"#fff"}}>₹{entryFee}</strong></div>
        </div>
        <Btn onClick={()=>{setStep(1);setForm({teamName:"",captain:"",email:"",phone:"",ffId:"",players:"",utr:""});}} style={{marginTop:16}} variant="secondary">Register Another Team</Btn>
      </Card>
    </div>
  );

  return (
    <div style={{padding:16}}>
      {/* Progress */}
      <div style={{display:"flex",gap:8,marginBottom:16,alignItems:"center"}}>
        {["Team Info","Payment","Done"].map((s,i)=>(
          <div key={i} style={{display:"flex",alignItems:"center",gap:8,flex:i<2?1:0}}>
            <div style={{display:"flex",alignItems:"center",gap:6}}>
              <div style={{width:24,height:24,borderRadius:"50%",background:step>i+1?"#00e676":step===i+1?"#ff6b00":"#1e1e2e",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,color:step>=i+1?"#fff":"#555",flexShrink:0}}>
                {step>i+1?"✓":i+1}
              </div>
              <span style={{fontSize:11,color:step===i+1?"#ff6b00":step>i+1?"#00e676":"#555",fontWeight:700}}>{s}</span>
            </div>
            {i<2&&<div style={{flex:1,height:2,background:step>i+1?"#00e676":"#1e1e2e",borderRadius:2}}/>}
          </div>
        ))}
      </div>

      {/* Slots left */}
      <Card style={{background:"linear-gradient(135deg,#1a1200,#2a1800)",border:"1px solid #ff6b0033",marginBottom:14}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div>
            <div style={{fontSize:13,fontWeight:700,color:"#ff6b00"}}>{tournamentName}</div>
            <div style={{fontSize:11,color:"#888",marginTop:2}}>Entry Fee: ₹{entryFee} per team</div>
          </div>
          <div style={{textAlign:"right"}}>
            <div style={{fontSize:18,fontWeight:800,color:maxTeams-approvedCount<=2?"#ff1744":"#00e676"}}>{maxTeams-approvedCount}</div>
            <div style={{fontSize:10,color:"#555"}}>SLOTS LEFT</div>
          </div>
        </div>
        <div style={{background:"#0a0a0f",borderRadius:6,height:6,overflow:"hidden",marginTop:10}}>
          <div style={{height:"100%",background:"linear-gradient(90deg,#ff6b00,#ff0055)",width:`${(approvedCount/maxTeams)*100}%`,transition:"width 0.4s"}}/>
        </div>
        <div style={{fontSize:10,color:"#555",marginTop:4,textAlign:"right"}}>{approvedCount}/{maxTeams} slots filled</div>
      </Card>

      {/* STEP 1 — Team Info */}
      {step===1 && (
        <Card>
          <div style={{fontSize:11,color:"#ff6b00",fontWeight:700,letterSpacing:1,marginBottom:14}}>TEAM INFORMATION</div>

          <Label>Team Name *</Label>
          <Inp placeholder="e.g. Shadow Wolves" value={form.teamName} onChange={e=>set("teamName",e.target.value)} style={{marginBottom:errors.teamName?4:12,borderColor:errors.teamName?"#ff1744":"#2a2a3a"}} />
          {errors.teamName&&<div style={{fontSize:11,color:"#ff1744",marginBottom:8}}>⚠ {errors.teamName}</div>}

          <Label>Captain's Name / Game ID *</Label>
          <Inp placeholder="Your Free Fire username" value={form.captain} onChange={e=>set("captain",e.target.value)} style={{marginBottom:errors.captain?4:12,borderColor:errors.captain?"#ff1744":"#2a2a3a"}} />
          {errors.captain&&<div style={{fontSize:11,color:"#ff1744",marginBottom:8}}>⚠ {errors.captain}</div>}

          <Label>Free Fire UID *</Label>
          <Inp placeholder="Your 9-digit FF UID" value={form.ffId} onChange={e=>set("ffId",e.target.value)} style={{marginBottom:errors.ffId?4:12,borderColor:errors.ffId?"#ff1744":"#2a2a3a"}} />
          {errors.ffId&&<div style={{fontSize:11,color:"#ff1744",marginBottom:8}}>⚠ {errors.ffId}</div>}

          <Label>Gmail Address *</Label>
          <Inp type="email" placeholder="captain@gmail.com" value={form.email} onChange={e=>set("email",e.target.value)} style={{marginBottom:errors.email?4:12,borderColor:errors.email?"#ff1744":"#2a2a3a"}} />
          {errors.email&&<div style={{fontSize:11,color:"#ff1744",marginBottom:8}}>⚠ {errors.email}</div>}

          <Label>WhatsApp Number *</Label>
          <Inp type="tel" placeholder="10-digit mobile number" value={form.phone} onChange={e=>set("phone",e.target.value)} style={{marginBottom:errors.phone?4:12,borderColor:errors.phone?"#ff1744":"#2a2a3a"}} />
          {errors.phone&&<div style={{fontSize:11,color:"#ff1744",marginBottom:8}}>⚠ {errors.phone}</div>}

          <Label>All 4 Player IDs (comma separated) *</Label>
          <Inp placeholder="Player1, Player2, Player3, Player4" value={form.players} onChange={e=>set("players",e.target.value)} style={{marginBottom:errors.players?4:12,borderColor:errors.players?"#ff1744":"#2a2a3a"}} />
          {errors.players&&<div style={{fontSize:11,color:"#ff1744",marginBottom:8}}>⚠ {errors.players}</div>}

          <Btn onClick={()=>{if(validate1())setStep(2);}}>Continue to Payment →</Btn>
        </Card>
      )}

      {/* STEP 2 — Payment */}
      {step===2 && (
        <Card>
          <div style={{fontSize:11,color:"#ff6b00",fontWeight:700,letterSpacing:1,marginBottom:14}}>PAYMENT</div>

          <div style={{background:"linear-gradient(135deg,#0d1a2a,#1a0d2a)",borderRadius:12,padding:16,marginBottom:14,border:"1px solid #29b6f633",textAlign:"center"}}>
            <div style={{fontSize:12,color:"#888",marginBottom:4}}>Pay Entry Fee via UPI</div>
            <div style={{fontSize:28,fontWeight:800,color:"#fff",marginBottom:4}}>₹{entryFee}</div>
            <div style={{fontSize:14,color:"#29b6f6",fontWeight:700,fontFamily:"monospace",background:"#0a0a0f",borderRadius:8,padding:"8px 12px",display:"inline-block",marginBottom:8}}>{upiId}</div>
            <div style={{fontSize:11,color:"#555"}}>Pay via GPay, PhonePe, Paytm, or any UPI app</div>
          </div>

          <div style={{background:"#0a0a0f",borderRadius:10,padding:12,marginBottom:14,border:"1px solid #2a2a3a"}}>
            <div style={{fontSize:11,color:"#888",marginBottom:6}}>PAYMENT STEPS</div>
            {["Open GPay / PhonePe / Paytm","Send ₹"+entryFee+" to the UPI ID above","Copy the UTR / Transaction ID","Paste it below and submit"].map((s,i)=>(
              <div key={i} style={{display:"flex",gap:8,alignItems:"flex-start",marginBottom:6}}>
                <div style={{width:18,height:18,borderRadius:"50%",background:"#ff6b00",color:"#fff",fontSize:10,fontWeight:800,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:1}}>{i+1}</div>
                <div style={{fontSize:12,color:"#aaa"}}>{s}</div>
              </div>
            ))}
          </div>

          <Label>UTR / Transaction Reference ID *</Label>
          <Inp placeholder="e.g. UTR123456789012" value={form.utr} onChange={e=>set("utr",e.target.value)} style={{marginBottom:14,fontFamily:"monospace",letterSpacing:1}} />

          <Btn onClick={()=>{if(form.utr.trim().length>5){onSubmit(form);setStep(3);}else setErrors({utr:"Enter valid UTR"});}}>
            ✅ Submit Registration
          </Btn>
          <Btn onClick={()=>setStep(1)} variant="secondary" style={{marginTop:8}}>← Back</Btn>
        </Card>
      )}
    </div>
  );
}

// ── ADMIN: APPLICATIONS ───────────────────────────────────
function Applications({ applications, setApplications, teams, setTeams }) {
  const [expanded, setExpanded] = useState(null);
  const pending = applications.filter(a=>a.status==="pending").length;

  const approve = (app) => {
    setApplications(applications.map(a=>a.id===app.id?{...a,status:"approved"}:a));
    const playerList = app.players.split(",").map(p=>p.trim());
    setTeams([...teams,{
      id:Date.now(), name:app.teamName, captain:app.captain,
      email:app.email, phone:app.phone, ffId:app.ffId,
      players:playerList, checkedIn:false, wins:0, losses:0, paid:true
    }]);
  };

  const reject = (id) => setApplications(applications.map(a=>a.id===id?{...a,status:"rejected"}:a));

  const sColors={pending:"orange",approved:"green",rejected:"red"};
  const sLabels={pending:"⏳ Pending",approved:"✅ Approved",rejected:"✗ Rejected"};

  return (
    <div style={{padding:16}}>
      <Card style={{background:"linear-gradient(135deg,#0d1a2a,#0d2a1a)",border:"1px solid #00e67633",marginBottom:14}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div style={{fontSize:12,color:"#00e676",fontWeight:700}}>🔐 Admin — Applications</div>
          {pending>0&&<Badge color="orange">{pending} pending</Badge>}
        </div>
      </Card>

      {applications.length===0&&(
        <Card style={{textAlign:"center",padding:"32px 20px",border:"1px dashed #2a2a3a"}}>
          <div style={{fontSize:40}}>📋</div>
          <div style={{color:"#555",marginTop:8,fontSize:14}}>No applications yet.</div>
        </Card>
      )}

      {applications.map(app=>(
        <Card key={app.id} style={{border:app.status==="pending"?"1px solid #ff6b0033":app.status==="approved"?"1px solid #00e67633":"1px solid #1e1e2e"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
            <div>
              <div style={{fontWeight:800,fontSize:15}}>{app.teamName}</div>
              <div style={{fontSize:11,color:"#888",marginTop:2}}>👑 {app.captain} · {app.appliedAt}</div>
            </div>
            <div style={{display:"flex",gap:6,alignItems:"center"}}>
              <Badge color={sColors[app.status]}>{sLabels[app.status]}</Badge>
              <button onClick={()=>setExpanded(expanded===app.id?null:app.id)} style={{background:"#1e1e2e",border:"none",color:"#aaa",borderRadius:8,width:28,height:28,cursor:"pointer",fontSize:12}}>{expanded===app.id?"▲":"▼"}</button>
            </div>
          </div>

          {expanded===app.id&&(
            <div style={{borderTop:"1px solid #1e1e2e",paddingTop:12,marginTop:4}}>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:12}}>
                {[["📧 Gmail",app.email],["📱 WhatsApp",app.phone],["🎮 FF UID",app.ffId],["💰 UTR",app.utr]].map(([k,v])=>(
                  <div key={k} style={{background:"#0a0a0f",borderRadius:8,padding:"8px 10px"}}>
                    <div style={{fontSize:10,color:"#555",marginBottom:2}}>{k}</div>
                    <div style={{fontSize:12,color:"#fff",fontWeight:600,wordBreak:"break-all"}}>{v}</div>
                  </div>
                ))}
              </div>
              <div style={{background:"#0a0a0f",borderRadius:8,padding:"8px 10px",marginBottom:12}}>
                <div style={{fontSize:10,color:"#555",marginBottom:2}}>👥 PLAYERS</div>
                <div style={{fontSize:12,color:"#fff"}}>{app.players}</div>
              </div>
              <div style={{background:"linear-gradient(135deg,#0d1a2a,#1a0d2a)",borderRadius:8,padding:"8px 10px",marginBottom:12,border:"1px solid #29b6f633"}}>
                <div style={{fontSize:10,color:"#29b6f6",marginBottom:2}}>💳 ENTRY FEE PAID</div>
                <div style={{fontSize:16,fontWeight:800,color:"#fff"}}>₹{app.entryFee}</div>
                <div style={{fontSize:11,color:"#888",fontFamily:"monospace"}}>Ref: {app.utr}</div>
              </div>
              {app.status==="pending"&&(
                <div style={{display:"flex",gap:8}}>
                  <Btn onClick={()=>approve(app)} variant="success" style={{flex:1}}>✅ Approve</Btn>
                  <Btn onClick={()=>reject(app.id)} variant="danger" style={{flex:1}}>✗ Reject</Btn>
                </div>
              )}
              {app.status==="approved"&&<div style={{textAlign:"center",fontSize:12,color:"#00e676",fontWeight:700}}>✅ Team added to tournament</div>}
              {app.status==="rejected"&&<div style={{textAlign:"center",fontSize:12,color:"#ff1744",fontWeight:700}}>✗ Application rejected</div>}
            </div>
          )}
        </Card>
      ))}
    </div>
  );
}

// ── STANDINGS ─────────────────────────────────────────────
function Standings({ teams, matches, prizePool, tournamentName }) {
  const [shareMsg, setShareMsg] = useState("");
  const lb = teams.map(t=>{
    let k=0,p=0,mc=0;
    matches.forEach(m=>{const e=m.results.find(r=>r.teamId===t.id);if(e){k+=e.kills;p+=getPlacementPts(e.place);mc++;}});
    return {...t,kills:k,placement:p,total:k+p,matchCount:mc};
  }).sort((a,b)=>b.total-a.total);
  const prizes=prizePool>0?[Math.round(prizePool*.5),Math.round(prizePool*.3),Math.round(prizePool*.2)]:[];
  const share=()=>{
    let text=`🔥 ${tournamentName.toUpperCase()} — STANDINGS 🔥\n\n`;
    lb.forEach((t,i)=>{const m=i===0?"🥇":i===1?"🥈":i===2?"🥉":`${i+1}.`;text+=`${m} ${t.name} — ${t.total}pts (${t.kills}K+${t.placement}P)\n`;});
    if(prizePool>0)text+=`\n💰 Prize Pool: ₹${prizePool.toLocaleString()}`;
    text+=`\nAfter ${matches.length} matches`;
    if(navigator.share)navigator.share({title:tournamentName,text});
    else{navigator.clipboard.writeText(text);setShareMsg("Copied!");setTimeout(()=>setShareMsg(""),2000);}
  };
  return (
    <div style={{padding:16}}>
      {prizePool>0&&(
        <Card style={{background:"linear-gradient(135deg,#1a1200,#2a1800)",border:"1px solid #ff6b0044",marginBottom:14}}>
          <div style={{fontSize:11,color:"#ff6b00",fontWeight:700,letterSpacing:1,marginBottom:8}}>💰 PRIZE POOL — ₹{prizePool.toLocaleString()}</div>
          <div style={{display:"flex",gap:8}}>
            {["🥇 1st","🥈 2nd","🥉 3rd"].map((label,i)=>(
              <div key={i} style={{flex:1,background:"#0a0a0f",borderRadius:9,padding:"8px",textAlign:"center"}}>
                <div style={{fontSize:11,color:"#888"}}>{label}</div>
                <div style={{fontSize:15,fontWeight:800,color:i===0?"#ff6b00":i===1?"#aaa":"#cd7f32"}}>₹{prizes[i]?.toLocaleString()||"—"}</div>
              </div>
            ))}
          </div>
        </Card>
      )}
      {matches.length===0&&(
        <Card style={{textAlign:"center",padding:"32px 20px",border:"1px dashed #2a2a3a"}}>
          <div style={{fontSize:40}}>🎮</div>
          <div style={{color:"#555",marginTop:8,fontSize:14}}>No matches yet.</div>
        </Card>
      )}
      {lb.map((team,i)=>(
        <div key={team.id} style={{display:"flex",alignItems:"center",gap:12,background:i===0?"linear-gradient(135deg,#1a1200,#2a1800)":"#13131a",border:i===0?"1px solid #ff6b0055":"1px solid #1e1e2e",borderRadius:14,padding:"12px 14px",marginBottom:10}}>
          <div style={{width:36,height:36,borderRadius:"50%",flexShrink:0,background:i===0?"#ff6b00":i===1?"#888":i===2?"#cd7f32":"#1e1e2e",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:i<3?18:13,color:i<3?"#fff":"#555"}}>
            {i===0?"🥇":i===1?"🥈":i===2?"🥉":i+1}
          </div>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontWeight:700,fontSize:15,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{team.name}</div>
            <div style={{display:"flex",gap:8,marginTop:4,flexWrap:"wrap"}}>
              <span style={{fontSize:11,color:"#888"}}>🎯 {team.kills}K</span>
              <span style={{fontSize:11,color:"#888"}}>🏅 {team.placement}P</span>
              <span style={{fontSize:11,color:"#888"}}>🎮 {team.matchCount}M</span>
            </div>
          </div>
          <div style={{textAlign:"right",flexShrink:0}}>
            <div style={{fontSize:24,fontWeight:800,color:i===0?"#ff6b00":"#f0f0f0"}}>{team.total}</div>
            <div style={{fontSize:10,color:"#555"}}>PTS</div>
            {prizes[i]>0&&<div style={{fontSize:10,color:"#ff6b00",fontWeight:700}}>₹{prizes[i]?.toLocaleString()}</div>}
          </div>
        </div>
      ))}
      {lb.length>0&&<Btn onClick={share} style={{marginTop:4}}>{shareMsg||"📤 Share Standings"}</Btn>}
      <Card style={{marginTop:16}}>
        <div style={{fontSize:11,fontWeight:700,color:"#ff6b00",letterSpacing:1,marginBottom:10}}>POINT SYSTEM</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:6}}>
          {[["🥇 Booyah","12"],["🥈 #2","9"],["🥉 #3","8"],["4th","7"],["5th","6"],["6th","5"],["7th","4"],["8th","3"],["9-10th","2"],["11-12th","1"],["Per Kill","1"]].map(([k,v])=>(
            <div key={k} style={{background:"#0a0a0f",borderRadius:8,padding:"6px 8px",textAlign:"center"}}>
              <div style={{fontSize:10,color:"#666"}}>{k}</div>
              <div style={{fontSize:15,fontWeight:800,color:"#ff6b00"}}>{v}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ── BRACKET ───────────────────────────────────────────────
function Bracket({ teams }) {
  const [fmt, setFmt] = useState("single");
  const seeded=[...teams].sort((a,b)=>b.wins-a.wins);
  const pairs=[];
  for(let i=0;i<Math.floor(seeded.length/2);i++)pairs.push([seeded[i],seeded[seeded.length-1-i]]);
  return (
    <div style={{padding:16}}>
      <div style={{display:"flex",gap:8,marginBottom:16}}>
        {["single","double","round-robin"].map(f=>(
          <button key={f} onClick={()=>setFmt(f)} style={{flex:1,padding:"9px 4px",borderRadius:10,border:"none",cursor:"pointer",background:fmt===f?"#ff6b00":"#13131a",color:fmt===f?"#fff":"#666",fontSize:11,fontWeight:700,textTransform:"capitalize"}}>{f.replace("-"," ")}</button>
        ))}
      </div>
      <Card style={{marginBottom:16}}>
        <div style={{fontSize:11,color:"#ff6b00",fontWeight:700,letterSpacing:1,marginBottom:8}}>{fmt.toUpperCase().replace("-"," ")} — ROUND 1</div>
        {pairs.map(([t1,t2],i)=>(
          <div key={i} style={{marginBottom:10}}>
            <div style={{fontSize:10,color:"#555",marginBottom:4}}>MATCH {i+1}</div>
            <div style={{display:"flex",alignItems:"center",gap:8}}>
              <div style={{flex:1,background:"#0a0a0f",borderRadius:9,padding:"10px 12px",border:"1px solid #2a2a3a"}}>
                <div style={{fontWeight:700,fontSize:13}}>{t1?.name||"TBD"}</div>
                <div style={{fontSize:10,color:"#888"}}>Seed #{seeded.indexOf(t1)+1}</div>
              </div>
              <div style={{color:"#ff6b00",fontWeight:800,fontSize:14,flexShrink:0}}>VS</div>
              <div style={{flex:1,background:"#0a0a0f",borderRadius:9,padding:"10px 12px",border:"1px solid #2a2a3a",textAlign:"right"}}>
                <div style={{fontWeight:700,fontSize:13}}>{t2?.name||"TBD"}</div>
                <div style={{fontSize:10,color:"#888"}}>Seed #{seeded.indexOf(t2)+1}</div>
              </div>
            </div>
          </div>
        ))}
      </Card>
    </div>
  );
}

// ── ADD MATCH ─────────────────────────────────────────────
function AddMatch({ teams, onSave }) {
  const [form,setForm]=useState({});const[name,setName]=useState("");const[saved,setSaved]=useState(false);
  const save=()=>{
    const results=teams.map(t=>({teamId:t.id,kills:parseInt(form[`k_${t.id}`]||0),place:parseInt(form[`p_${t.id}`]||13)}));
    onSave({id:Date.now(),name:name||`Match`,results});
    setForm({});setName("");setSaved(true);setTimeout(()=>setSaved(false),2000);
  };
  return (
    <div style={{padding:16}}>
      <Card style={{background:"linear-gradient(135deg,#0d1a2a,#0d2a1a)",border:"1px solid #00e67633",marginBottom:14}}>
        <div style={{fontSize:12,color:"#00e676",fontWeight:700}}>🔐 Admin Mode</div>
      </Card>
      <Inp placeholder="Match name" value={name} onChange={e=>setName(e.target.value)} style={{marginBottom:14}}/>
      {teams.map(t=>(
        <Card key={t.id}>
          <div style={{fontWeight:700,color:"#ff6b00",marginBottom:10}}>{t.name}</div>
          <div style={{display:"flex",gap:10}}>
            <div style={{flex:1}}><Label>PLACEMENT</Label><Inp type="number" min="1" max="12" placeholder="1–12" value={form[`p_${t.id}`]||""} onChange={e=>setForm({...form,[`p_${t.id}`]:e.target.value})} style={{textAlign:"center",fontSize:18,fontWeight:700}}/></div>
            <div style={{flex:1}}><Label>KILLS</Label><Inp type="number" min="0" placeholder="0" value={form[`k_${t.id}`]||""} onChange={e=>setForm({...form,[`k_${t.id}`]:e.target.value})} style={{textAlign:"center",fontSize:18,fontWeight:700}}/></div>
            <div style={{flex:1}}><Label>PTS</Label><div style={{background:"#0a0a0f",border:"1px solid #2a2a3a",borderRadius:10,padding:"11px",textAlign:"center",fontSize:18,fontWeight:800,color:"#ff6b00"}}>{parseInt(form[`k_${t.id}`]||0)+getPlacementPts(parseInt(form[`p_${t.id}`]||13))}</div></div>
          </div>
        </Card>
      ))}
      <Btn onClick={save} style={{marginTop:4}}>{saved?"✅ Saved!":"💾 Save Match"}</Btn>
    </div>
  );
}

// ── TEAMS ADMIN ───────────────────────────────────────────
function Teams({ teams, setTeams }) {
  const [expanded,setExpanded]=useState(null);
  const toggleCheckin=id=>setTeams(teams.map(t=>t.id===id?{...t,checkedIn:!t.checkedIn}:t));
  const removeTeam=id=>setTeams(teams.filter(t=>t.id!==id));
  const checkedCount=teams.filter(t=>t.checkedIn).length;
  return (
    <div style={{padding:16}}>
      <Card style={{background:"linear-gradient(135deg,#0d1a2a,#0d2a1a)",border:"1px solid #00e67633",marginBottom:14}}>
        <div style={{fontSize:12,color:"#00e676",fontWeight:700}}>🔐 Admin — Approved Teams</div>
      </Card>
      <Card style={{marginBottom:16}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
          <div style={{fontSize:11,color:"#ff6b00",fontWeight:700,letterSpacing:1}}>CHECK-IN</div>
          <Badge color={checkedCount===teams.length&&teams.length>0?"green":"orange"}>{checkedCount}/{teams.length} Ready</Badge>
        </div>
        <div style={{background:"#0a0a0f",borderRadius:8,height:8,overflow:"hidden"}}>
          <div style={{height:"100%",background:"linear-gradient(90deg,#ff6b00,#00e676)",width:`${(checkedCount/Math.max(teams.length,1))*100}%`,transition:"width 0.4s"}}/>
        </div>
      </Card>
      {teams.length===0&&<Card style={{textAlign:"center",padding:"24px",border:"1px dashed #2a2a3a"}}><div style={{color:"#555",fontSize:13}}>No approved teams yet. Approve applications first.</div></Card>}
      {teams.map(t=>(
        <Card key={t.id}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontWeight:700,fontSize:14,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{t.name}</div>
              <div style={{fontSize:11,color:"#888",marginTop:2}}>👑 {t.captain}</div>
            </div>
            <Badge color={t.checkedIn?"green":"red"}>{t.checkedIn?"✓ In":"✗ Out"}</Badge>
            <button onClick={()=>setExpanded(expanded===t.id?null:t.id)} style={{background:"#1e1e2e",border:"none",color:"#aaa",borderRadius:8,width:30,height:30,cursor:"pointer",fontSize:12}}>{expanded===t.id?"▲":"▼"}</button>
          </div>
          {expanded===t.id&&(
            <div style={{marginTop:12,borderTop:"1px solid #1e1e2e",paddingTop:12}}>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:10}}>
                {[["📧",t.email||"—"],["📱",t.phone||"—"],["🎮 FF UID",t.ffId||"—"],["💰",t.paid?"Paid ✓":"Unpaid"]].map(([k,v])=>(
                  <div key={k} style={{background:"#0a0a0f",borderRadius:8,padding:"7px 9px"}}>
                    <div style={{fontSize:10,color:"#555"}}>{k}</div>
                    <div style={{fontSize:11,color:"#fff",wordBreak:"break-all"}}>{v}</div>
                  </div>
                ))}
              </div>
              <div style={{display:"flex",gap:8}}>
                <button onClick={()=>toggleCheckin(t.id)} style={{flex:1,padding:"9px",borderRadius:9,border:"none",background:t.checkedIn?"#2a0d0d":"#0d2a1a",color:t.checkedIn?"#ff1744":"#00e676",fontWeight:700,fontSize:12,cursor:"pointer"}}>
                  {t.checkedIn?"✗ Undo":"✓ Check In"}
                </button>
                <button onClick={()=>removeTeam(t.id)} style={{padding:"9px 14px",borderRadius:9,border:"none",background:"#2a0d0d",color:"#ff1744",fontWeight:700,fontSize:13,cursor:"pointer"}}>🗑</button>
              </div>
            </div>
          )}
        </Card>
      ))}
    </div>
  );
}

// ── DISPUTES ──────────────────────────────────────────────
function Disputes({ isAdmin }) {
  const [disputes,setDisputes]=useState([
    {id:1,team:"Alpha Squad",match:"Match 1",issue:"Wrong kill count — we had 10 kills not 8",status:"pending",time:"2h ago"},
    {id:2,team:"BloodHawk",match:"Match 2",issue:"Placement marked #5 but we finished #3",status:"reviewing",time:"45m ago"},
  ]);
  const [nd,setNd]=useState({team:"",match:"",issue:""});
  const [submitted,setSubmitted]=useState(false);
  const submit=()=>{if(!nd.team||!nd.issue)return;setDisputes([...disputes,{id:Date.now(),...nd,status:"pending",time:"just now"}]);setNd({team:"",match:"",issue:""});setSubmitted(true);setTimeout(()=>setSubmitted(false),2500);};
  const setStatus=(id,s)=>setDisputes(disputes.map(d=>d.id===id?{...d,status:s}:d));
  const sC={pending:"orange",reviewing:"orange",resolved:"green",rejected:"red"};
  const sL={pending:"⏳ Pending",reviewing:"🔍 Reviewing",resolved:"✅ Resolved",rejected:"✗ Rejected"};
  return (
    <div style={{padding:16}}>
      <Card>
        <div style={{fontSize:11,color:"#ff6b00",fontWeight:700,letterSpacing:1,marginBottom:12}}>SUBMIT DISPUTE</div>
        <Inp placeholder="Your team name" value={nd.team} onChange={e=>setNd({...nd,team:e.target.value})} style={{marginBottom:8}}/>
        <Inp placeholder="Which match?" value={nd.match} onChange={e=>setNd({...nd,match:e.target.value})} style={{marginBottom:8}}/>
        <textarea placeholder="Describe the issue clearly..." value={nd.issue} onChange={e=>setNd({...nd,issue:e.target.value})} style={{width:"100%",padding:"11px 13px",background:"#0a0a0f",border:"1px solid #2a2a3a",borderRadius:10,color:"#fff",fontSize:13,boxSizing:"border-box",resize:"vertical",minHeight:80,fontFamily:"inherit",marginBottom:10,outline:"none"}}/>
        <Btn onClick={submit}>{submitted?"✅ Submitted!":"⚠️ Submit Dispute"}</Btn>
      </Card>
      <div style={{fontSize:11,color:"#ff6b00",fontWeight:700,letterSpacing:1,marginBottom:8}}>DISPUTES ({disputes.length})</div>
      {disputes.map(d=>(
        <Card key={d.id}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
            <div><div style={{fontWeight:700,fontSize:14}}>{d.team}</div><div style={{fontSize:11,color:"#888"}}>{d.match} · {d.time}</div></div>
            <Badge color={sC[d.status]}>{sL[d.status]}</Badge>
          </div>
          <div style={{fontSize:13,color:"#aaa",background:"#0a0a0f",borderRadius:8,padding:"9px 11px",marginBottom:isAdmin?10:0}}>{d.issue}</div>
          {isAdmin&&<div style={{display:"flex",gap:6}}><button onClick={()=>setStatus(d.id,"reviewing")} style={{flex:1,padding:"7px",borderRadius:8,border:"none",background:"#2a1a0d",color:"#ff6b00",fontWeight:700,fontSize:11,cursor:"pointer"}}>🔍 Review</button><button onClick={()=>setStatus(d.id,"resolved")} style={{flex:1,padding:"7px",borderRadius:8,border:"none",background:"#0d2a1a",color:"#00e676",fontWeight:700,fontSize:11,cursor:"pointer"}}>✅ Resolve</button><button onClick={()=>setStatus(d.id,"rejected")} style={{flex:1,padding:"7px",borderRadius:8,border:"none",background:"#2a0d0d",color:"#ff1744",fontWeight:700,fontSize:11,cursor:"pointer"}}>✗ Reject</button></div>}
        </Card>
      ))}
    </div>
  );
}

// ── RULES ─────────────────────────────────────────────────
function Rules() {
  const [open,setOpen]=useState(null);
  return (
    <div style={{padding:16}}>
      <Card style={{background:"linear-gradient(135deg,#1a1200,#2a1800)",border:"1px solid #ff6b0033",marginBottom:16}}>
        <div style={{fontSize:13,fontWeight:700,color:"#ff6b00",marginBottom:4}}>📋 Official Tournament Rules</div>
        <div style={{fontSize:12,color:"#aaa"}}>Read all rules before joining. Ignorance is not an excuse.</div>
      </Card>
      {RULES.map((r,i)=>(
        <Card key={i} style={{cursor:"pointer"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}} onClick={()=>setOpen(open===i?null:i)}>
            <div style={{fontWeight:700,fontSize:14}}>{r.title}</div>
            <span style={{color:"#ff6b00",fontSize:16}}>{open===i?"▲":"▼"}</span>
          </div>
          {open===i&&<div style={{marginTop:10,fontSize:13,color:"#aaa",lineHeight:1.6,borderTop:"1px solid #1e1e2e",paddingTop:10}}>{r.content}</div>}
        </Card>
      ))}
    </div>
  );
}

// ── SETTINGS ─────────────────────────────────────────────
function Settings({ tournamentName,setTournamentName,prizePool,setPrizePool,entryFee,setEntryFee,upiId,setUpiId,maxTeams,setMaxTeams,matches,setMatches,onLogout }) {
  const [tN,setTN]=useState(tournamentName);const[pp,setPP]=useState(prizePool);const[ef,setEF]=useState(entryFee);const[upi,setUpi]=useState(upiId);const[mt,setMT]=useState(maxTeams);const[saved,setSaved]=useState(false);
  const save=()=>{setTournamentName(tN);setPrizePool(parseInt(pp)||0);setEntryFee(parseInt(ef)||0);setUpiId(upi);setMaxTeams(parseInt(mt)||12);setSaved(true);setTimeout(()=>setSaved(false),2000);};
  return (
    <div style={{padding:16}}>
      <Card style={{background:"linear-gradient(135deg,#0d1a2a,#0d2a1a)",border:"1px solid #00e67633",marginBottom:14}}>
        <div style={{fontSize:12,color:"#00e676",fontWeight:700}}>🔐 Admin Settings</div>
      </Card>
      <Card>
        <div style={{fontSize:11,color:"#ff6b00",fontWeight:700,letterSpacing:1,marginBottom:12}}>TOURNAMENT INFO</div>
        <Label>Tournament Name</Label><Inp placeholder="FF Champions Cup" value={tN} onChange={e=>setTN(e.target.value)} style={{marginBottom:10}}/>
        <Label>Max Teams (slots)</Label><Inp type="number" placeholder="12" value={mt} onChange={e=>setMT(e.target.value)} style={{marginBottom:10}}/>
        <Label>Prize Pool (₹)</Label><Inp type="number" placeholder="5000" value={pp} onChange={e=>setPP(e.target.value)} style={{marginBottom:10}}/>
        <Label>Entry Fee per Team (₹)</Label><Inp type="number" placeholder="200" value={ef} onChange={e=>setEF(e.target.value)} style={{marginBottom:10}}/>
        <Label>Your UPI ID (for payments)</Label><Inp placeholder="yourname@upi" value={upi} onChange={e=>setUpi(e.target.value)} style={{marginBottom:12}}/>
        <Btn onClick={save}>{saved?"✅ Saved!":"💾 Save Settings"}</Btn>
      </Card>
      <Card>
        <div style={{fontSize:11,color:"#ff6b00",fontWeight:700,letterSpacing:1,marginBottom:10}}>DATA</div>
        <div style={{fontSize:13,color:"#aaa",marginBottom:12}}>Matches: <strong style={{color:"#fff"}}>{matches.length}</strong></div>
        <Btn onClick={()=>{if(window.confirm("Delete ALL match data?"))setMatches([]);}} variant="danger">🗑 Clear Match Data</Btn>
      </Card>
      <Btn onClick={onLogout} variant="secondary" style={{marginTop:4}}>🔒 Lock Dashboard</Btn>
    </div>
  );
}

// ── ROOT ──────────────────────────────────────────────────
export default function App() {
  const [isAdmin,setIsAdmin]=useState(false);
  const [showAdminLogin,setShowAdminLogin]=useState(false);
  const [tab,setTab]=useState(0);
  const [teams,setTeams]=useState(sampleTeams);
  const [matches,setMatches]=useState([]);
  const [applications,setApplications]=useState(sampleApplications);
  const [tournamentName,setTournamentName]=useState("FF Champions Cup");
  const [prizePool,setPrizePool]=useState(5000);
  const [entryFee,setEntryFee]=useState(200);
  const [upiId,setUpiId]=useState("yourname@upi");
  const [maxTeams,setMaxTeams]=useState(12);

  const approvedCount=applications.filter(a=>a.status==="approved").length + teams.length;
  const pendingCount=applications.filter(a=>a.status==="pending").length;

  const addMatch=m=>setMatches(p=>[...p,m]);
  const addApplication=form=>setApplications(p=>[...p,{
    id:Date.now(),teamName:form.teamName,captain:form.captain,
    email:form.email,phone:form.phone,ffId:form.ffId,
    players:form.players,entryFee,utr:form.utr,
    status:"pending",appliedAt:"just now"
  }]);

  const PUBLIC_TABS=["🏆 Standings","📝 Join","⚠️ Disputes","📋 Rules"];
  const ADMIN_TABS=["🏆 Standings","🎯 Bracket","➕ Match","👥 Teams",`📋 Apps${pendingCount>0?` (${pendingCount})`:""}` ,"⚠️ Disputes","⚙️ Settings"];

  const tabs=isAdmin?ADMIN_TABS:PUBLIC_TABS;

  const getScreen=()=>{
    if(isAdmin){
      return [
        <Standings teams={teams} matches={matches} prizePool={prizePool} tournamentName={tournamentName}/>,
        <Bracket teams={teams}/>,
        <AddMatch teams={teams} onSave={addMatch}/>,
        <Teams teams={teams} setTeams={setTeams}/>,
        <Applications applications={applications} setApplications={setApplications} teams={teams} setTeams={setTeams}/>,
        <Disputes isAdmin={true}/>,
        <Settings tournamentName={tournamentName} setTournamentName={setTournamentName} prizePool={prizePool} setPrizePool={setPrizePool} entryFee={entryFee} setEntryFee={setEntryFee} upiId={upiId} setUpiId={setUpiId} maxTeams={maxTeams} setMaxTeams={setMaxTeams} matches={matches} setMatches={setMatches} onLogout={()=>{setIsAdmin(false);setTab(0);}}/>,
      ][Math.min(tab,6)];
    }
    return [
      <Standings teams={teams} matches={matches} prizePool={prizePool} tournamentName={tournamentName}/>,
      <Register tournamentName={tournamentName} entryFee={entryFee} upiId={upiId} maxTeams={maxTeams} approvedCount={approvedCount} onSubmit={addApplication}/>,
      <Disputes isAdmin={false}/>,
      <Rules/>,
    ][Math.min(tab,3)];
  };

  if(showAdminLogin) return <AdminLock onUnlock={()=>{setIsAdmin(true);setShowAdminLogin(false);setTab(0);}}/>;

  return (
    <div style={{minHeight:"100vh",background:"#0a0a0f",color:"#f0f0f0",fontFamily:"'Segoe UI',system-ui,sans-serif",maxWidth:480,margin:"0 auto",paddingBottom:72}}>
      <div style={{background:"linear-gradient(135deg,#ff6b00 0%,#ff0055 100%)",padding:"18px 16px 14px",position:"sticky",top:0,zIndex:20}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
          <div>
            <div style={{fontSize:10,letterSpacing:3,opacity:0.8,textTransform:"uppercase"}}>Free Fire Esports</div>
            <div style={{fontSize:20,fontWeight:800,letterSpacing:-0.5}}>{tournamentName}</div>
            <div style={{fontSize:11,opacity:0.75,marginTop:1}}>
              {matches.length} matches · {teams.length} teams · {maxTeams-approvedCount} slots left
              {pendingCount>0&&isAdmin&&<span style={{color:"#fff",fontWeight:700}}> · ⏳{pendingCount} pending</span>}
            </div>
          </div>
          <button onClick={()=>isAdmin?null:setShowAdminLogin(true)} style={{background:isAdmin?"#00e67622":"rgba(0,0,0,0.2)",border:isAdmin?"1px solid #00e67666":"1px solid rgba(255,255,255,0.2)",borderRadius:8,padding:"6px 10px",color:isAdmin?"#00e676":"#fff",fontSize:11,fontWeight:700,cursor:"pointer",flexShrink:0}}>
            {isAdmin?"🔐 Admin":"🔑 Admin"}
          </button>
        </div>
      </div>

      <div style={{minHeight:"calc(100vh-140px)"}}>{getScreen()}</div>

      <div style={{position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:480,background:"#0d0d14",borderTop:"1px solid #1e1e2e",display:"flex",zIndex:20}}>
        {tabs.map((n,i)=>{
          const emoji=n.split(" ")[0];
          const label=n.replace(emoji,"").trim().split("(")[0].trim();
          const hasBadge=n.includes("(")&&n.includes(")");
          const badgeNum=hasBadge?n.match(/\((\d+)\)/)?.[1]:"";
          return (
            <button key={i} onClick={()=>setTab(i)} style={{flex:1,padding:"10px 2px 8px",border:"none",background:"none",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:1,position:"relative"}}>
              <span style={{fontSize:15}}>{emoji}</span>
              <span style={{fontSize:7,color:tab===i?"#ff6b00":"#444",fontWeight:700,letterSpacing:0.3,textAlign:"center",lineHeight:1.2}}>{label.substring(0,6)}</span>
              {tab===i&&<div style={{width:16,height:2,background:"#ff6b00",borderRadius:2}}/>}
              {hasBadge&&badgeNum&&<div style={{position:"absolute",top:6,right:6,background:"#ff1744",borderRadius:"50%",width:14,height:14,display:"flex",alignItems:"center",justifyContent:"center",fontSize:8,fontWeight:800,color:"#fff"}}>{badgeNum}</div>}
            </button>
          );
        })}
      </div>
    </div>
  );
}
